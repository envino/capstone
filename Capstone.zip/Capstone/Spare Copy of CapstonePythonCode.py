#Python Script for Capstone Project
#Andy Horne
#Nate Kim
#Raphael Santanos

#import libraries
from gpiozero import Button
from picamera import PiCamera
from datetime import datetime
from time import sleep
import boto3
import os
import requests

#Wait for internet connection
def internet_connected(url='http://google.com',timeout=5):
    try:
        _ = requests.get(url,timeout=timeout)
        return True
    except requests.ConnectionError:
        print ('No Internet')
        return False
    
while True:
        if internet_connected():
            print ('connected')
            break
        else:
            print ('not connected')

#configuration
s3 = boto3.resource('s3')

button = Button(2)
camera = PiCamera()
camera.rotation = 180
camera.resolution = (1920, 1080)

#system startup sound here
os.system('mpg123 /home/pi/Desktop/Capstone/strongerkanye.mp3')

#define functions
def capture():
    print('beginning capture')
    for i in range(1):
        i = datetime.now().strftime('%Y%m%d%H%M%S')
        sleep(0)
        camera.capture('/home/pi/Desktop/Capstone/Capstone Images/%s.jpg' % i)
        print('captured image: ',i)
        print('uploading image: ',i)
        s3.meta.client.upload_file('/home/pi/Desktop/Capstone/Capstone Images/%s.jpg' % i, 'raspberrypicapstone', '%s' % i)
        s3.meta.client.upload_file('/home/pi/Desktop/Capstone/Capstone Images/%s.jpg' % i, 'raspberryindex', '%s' % i)
        print('Finished Uploading Image: ',i)
        os.remove('/home/pi/Desktop/Capstone/Capstone Images/%s.jpg' % i)
        print('image removed', i)
        print('*****')
    print('completed capture')
    print('*****')
    
    doorbell()
    

def doorbell():
        print('Press the doorbell to capture another set of images')        
                                                                                                                                                                                                                                  
while True:                      
    if button.is_pressed:
        capture()
        os.system('mpg123 /home/pi/Desktop/Capstone/doorbelltrimmed.mp3')
   # else:
    #    os.system('mpg123 /home/pi/Desktop/Capstone/doorbell2trimmed.mp3')







                                         

